-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: 12-Mar-2020 às 21:34
-- Versão do servidor: 5.7.26
-- versão do PHP: 7.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mydb`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_materia`
--

DROP TABLE IF EXISTS `tb_materia`;
CREATE TABLE IF NOT EXISTS `tb_materia` (
  `materia_id` int(11) NOT NULL AUTO_INCREMENT,
  `materia_nome` varchar(45) NOT NULL,
  `materia_tipo` varchar(45) NOT NULL,
  PRIMARY KEY (`materia_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `tb_materia`
--

INSERT INTO `tb_materia` (`materia_id`, `materia_nome`, `materia_tipo`) VALUES
(1, 'Português', ''),
(2, 'Matemática', ''),
(3, 'Biologia', ''),
(4, 'Quimíca', ''),
(5, 'Física', ''),
(6, 'Inglês', ''),
(7, 'Espanhol', ''),
(8, 'Geografia', ''),
(9, 'História', ''),
(10, 'Artes', ''),
(11, 'Filosofia', ''),
(12, 'Sociologia', ''),
(13, 'Educação Física', ''),
(14, 'Projeto de Vida', '');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_materia_has_tb_professor`
--

DROP TABLE IF EXISTS `tb_materia_has_tb_professor`;
CREATE TABLE IF NOT EXISTS `tb_materia_has_tb_professor` (
  `tb_materia_meteria_id` int(11) NOT NULL,
  `tb_professor_professor_id` int(11) NOT NULL,
  PRIMARY KEY (`tb_materia_meteria_id`,`tb_professor_professor_id`),
  KEY `fk_tb_materia_has_tb_professor_tb_professor1_idx` (`tb_professor_professor_id`),
  KEY `fk_tb_materia_has_tb_professor_tb_materia1_idx` (`tb_materia_meteria_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `tb_materia_has_tb_professor`
--

INSERT INTO `tb_materia_has_tb_professor` (`tb_materia_meteria_id`, `tb_professor_professor_id`) VALUES
(1, 5),
(4, 10),
(8, 11),
(9, 14),
(6, 15),
(13, 16),
(7, 17),
(5, 18),
(10, 19),
(2, 20),
(11, 22),
(12, 22);

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_professor`
--

DROP TABLE IF EXISTS `tb_professor`;
CREATE TABLE IF NOT EXISTS `tb_professor` (
  `professor_id` int(11) NOT NULL AUTO_INCREMENT,
  `professor_nome` varchar(45) NOT NULL,
  `professor_email` varchar(500) NOT NULL,
  `professor_senha` varchar(50) NOT NULL,
  `professor_telefone` varchar(500) NOT NULL,
  `professor_data` varchar(10) NOT NULL,
  PRIMARY KEY (`professor_id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `tb_professor`
--

INSERT INTO `tb_professor` (`professor_id`, `professor_nome`, `professor_email`, `professor_senha`, `professor_telefone`, `professor_data`) VALUES
(5, 'Géssica', 'gessica@gmail.com', 'gessica', '33431703', '22/04/2019'),
(6, 'Luis', 'luis@gmail.com', 'luis', '33431703', '13/07/2018'),
(7, 'Aerton', 'aerton@gmail.com', 'aerton', '33431703', '05/02/2019'),
(8, 'Carlos', 'carlos@gmail.com', 'carlos', '33431703', '27/01/2015'),
(9, 'Jardel', 'jardel@gmail.com', 'jardel', '33431703', '18/03/2017'),
(10, 'Laercio', 'laercio@gmail.com', 'laercio', '33431703', '23/06/2009'),
(11, 'Moisés', 'moises@gmail.com', 'moises', '33431703', '12/02/2010'),
(14, 'Herberth', 'herberth@gmail.com', 'herberth', '33431703', '14/02/2009'),
(15, 'Claudiane', 'claudiane@gmail.com', 'claudiane', '33431703', '17/06/2019'),
(16, 'Luciane', 'luciane@gmail.com', 'luciane', '33431703', '03/02/2010'),
(17, 'Patricia', 'patricia@gmail.com', 'patricia', '33431703', '03/02/2010'),
(18, 'Rafaela', 'rafaela@gmail.com', 'rafaela', '33431703', '03/02/2015'),
(19, 'Zeneide', 'zeneide@gmail.com', 'zeneide', '33431703', '03/02/2010'),
(20, 'Ricardo', 'ricardo@gmail.com', 'ricardo', '33431703', '23/06/2018'),
(21, 'Lidiana', 'lidiana@gmail.com', 'lidiana', '33431703', '03/02/2010'),
(22, 'Alexandre', 'alexandre@gmail.com', 'alexandre', '33431703', '03/02/2020');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_professor_has_tb_turma`
--

DROP TABLE IF EXISTS `tb_professor_has_tb_turma`;
CREATE TABLE IF NOT EXISTS `tb_professor_has_tb_turma` (
  `tb_professor_professor_id` int(11) NOT NULL,
  `tb_turma_turma_id` int(11) NOT NULL,
  PRIMARY KEY (`tb_professor_professor_id`,`tb_turma_turma_id`),
  KEY `fk_tb_professor_has_tb_turma_tb_turma1_idx` (`tb_turma_turma_id`),
  KEY `fk_tb_professor_has_tb_turma_tb_professor_idx` (`tb_professor_professor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_turma`
--

DROP TABLE IF EXISTS `tb_turma`;
CREATE TABLE IF NOT EXISTS `tb_turma` (
  `turma_id` int(11) NOT NULL AUTO_INCREMENT,
  `turma_serie` varchar(45) NOT NULL,
  `turma_curso` varchar(45) NOT NULL,
  PRIMARY KEY (`turma_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `tb_turma`
--

INSERT INTO `tb_turma` (`turma_id`, `turma_serie`, `turma_curso`) VALUES
(1, '1º', 'Redes de Computadores'),
(2, '1º', 'Enfermagem'),
(3, '1º', 'Administração'),
(4, '1º', 'Informática'),
(5, '2º', 'Enfermagem'),
(6, '2º', 'Finanças'),
(7, '2º', 'Agropecuária'),
(8, '2º', 'Informática'),
(9, '3º', 'Enfermagem'),
(10, '3º', 'Informática'),
(11, '3º', 'Redes de Computadores'),
(12, '3º', 'Segurança do Trabalho');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_turma_has_tb_materia`
--

DROP TABLE IF EXISTS `tb_turma_has_tb_materia`;
CREATE TABLE IF NOT EXISTS `tb_turma_has_tb_materia` (
  `tb_turma_turma_id` int(11) NOT NULL,
  `tb_materia_meteria_id` int(11) NOT NULL,
  PRIMARY KEY (`tb_turma_turma_id`,`tb_materia_meteria_id`),
  KEY `fk_tb_turma_has_tb_materia_tb_materia1_idx` (`tb_materia_meteria_id`),
  KEY `fk_tb_turma_has_tb_materia_tb_turma1_idx` (`tb_turma_turma_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Constraints for dumped tables
--

--
-- Limitadores para a tabela `tb_materia_has_tb_professor`
--
ALTER TABLE `tb_materia_has_tb_professor`
  ADD CONSTRAINT `fk_tb_materia_has_tb_professor_tb_materia1` FOREIGN KEY (`tb_materia_meteria_id`) REFERENCES `tb_materia` (`materia_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_tb_materia_has_tb_professor_tb_professor1` FOREIGN KEY (`tb_professor_professor_id`) REFERENCES `tb_professor` (`professor_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `tb_professor_has_tb_turma`
--
ALTER TABLE `tb_professor_has_tb_turma`
  ADD CONSTRAINT `fk_tb_professor_has_tb_turma_tb_professor` FOREIGN KEY (`tb_professor_professor_id`) REFERENCES `tb_professor` (`professor_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_tb_professor_has_tb_turma_tb_turma1` FOREIGN KEY (`tb_turma_turma_id`) REFERENCES `tb_turma` (`turma_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `tb_turma_has_tb_materia`
--
ALTER TABLE `tb_turma_has_tb_materia`
  ADD CONSTRAINT `fk_tb_turma_has_tb_materia_tb_materia1` FOREIGN KEY (`tb_materia_meteria_id`) REFERENCES `tb_materia` (`materia_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_tb_turma_has_tb_materia_tb_turma1` FOREIGN KEY (`tb_turma_turma_id`) REFERENCES `tb_turma` (`turma_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
