<?php
	require_once('../controller/cProfessores.php');

	$cProfessores = new cProfessores();
	if (isset($_POST['cad_nome']) && isset($_POST['cad_sobrenome']) && isset($_POST['cad_email']) && isset($_POST['cad_senha']) && isset($_POST['cad_telefone']) && isset($_POST['cad_cpf']) && isset($_POST['cad_nasc']) && isset($_POST['cad_disciplina']) && isset($_POST['cad_folgas'])) {
		$cProfessores->Inserir($_POST['cad_nome'], $_POST['cad_sobrenome'], $_POST['cad_email'], $_POST['cad_senha'], $_POST['cad_telefone'], $_POST['cad_cpf'], $_POST['cad_nasc'], $_POST['cad_disciplina'], $_POST['cad_folgas']);
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="css/estilo.css">

</head>
<body>
	<nav id="menu">
	    <ul>
	        <li><a href="index.php">Home</a></li>
	        <li><a href="turmas.php">Turmas</a></li>
	        <li><a href="cadastro.php">Cadastro</a></li>
	    </ul>
	</nav>
	<form method="POST" action="../controller/cadastrarProf.php">
		Nome<input type="text" name="cad_nome"><br><br>
		Sobrenome<input type="text" name="cad_sobrenome"><br><br>
		Email<input type="text" name="cad_email"><br><br>
		Senha<input type="password" name="cad_senha"><br><br>
		Telefone<input type="number" name="cad_telefone"><br><br>
		CPF<input type="number" name="cad_cpf"><br><br>
		Data de Nascimento<input type="date" name="cad_nasc"><br><br>
		Data de Disciplina<input type="text" name="cad_disciplina"><br><br>
		Data de Folgas<input type="text" name="cad_folgas"><br><br>

		<input type="submit" value="Cadastrar">
	</form>
</body>
</html>