<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="css/estilo.css">
</head>
<body>
	<nav id="menu">
	    <ul>
	        <li><a href="index.php">Home</a></li>
	        <li><a href="turmas.php">Turmas</a></li>
	        <li><a href="cadastro.php">Cadastro</a></li>
	    </ul>
	</nav>
	<form method="GET" action="#">
        <h3>PESQUISAR PROFESSOR</h3>
        Pesquisar:<input type="text" name="pesquisar"><br><br>
        <input type="submit" value="Pesquisar"><br><br>
    </form>
	<?php
    require_once("../controller/cProfessores.php");
    echo"
    <div style='overflow-x:auto;' class='container'>
        <table  class='bordered striped centered'>
        
            <tr>
                <td>ID</td>
                <td>Nome</td>
                <td>Sobrenome</td>
                <td>Atuação</td>
                <td>Email</td>
                <td>Folgas</td>
                <td>Telefone</td>
                <td>Editar</td>
                <td>Excluir</td>
            </tr>
            
            ";
    if (isset($_GET['pesquisar'])) {
        $cprofessores = new cProfessores();
        $sql = $cprofessores->Pesquisar($_GET['pesquisar']);
        while ($dados = mysqli_fetch_assoc($sql)) {
            echo "
            <tr>
                <td>".$dados['professor_id']."</td>
                <td>".$dados['professor_nome']."</td>
                <td>".$dados['professor_sobrenome']."</td>
                <td>".$dados['professor_atuacao']."</td>
                <td>".$dados['professor_email']."</td>
                <td>".$dados['professor_folga']."</td>
                <td>".$dados['professor_telefone']."</td>
                <td><a href='editarProfessores.php?id={$dados['professor_id']}'>Editar</a></td>
                <td><a href='excluirPro.php?id={$dados['professor_id']}'>Excluir</a></td>
            <tr/>";
        }
    }
    echo "</table><br></div>";
    ?>

	
</body>
</html>