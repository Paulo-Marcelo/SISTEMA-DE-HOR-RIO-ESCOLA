<div id="DivLateral">
		<div id="DivA">
			<h3>Q<br>u<br>i<br>n<br>t<br>a<br>-<br>F<br>e<br>i<br>r<br>a</h3>
		</div>
		<div style='overflow-x:auto;'>

			<table class='bordered striped centered'>
				<tr>
					<td>1º <br>Enfermagem</td>
					<td>1º <br>Informática</td>
					<td>1º <br>Redes de Computadores</td>
					<td>1º <br>Administração</td>
					<td>2º <br>Enfermagem</td>
					<td>2º <br>Informática</td>
					<td>2º <br>Agropecuária</td>
					<td>2º <br>Finanças</td>
					<td>3º <br>Enfermagem</td>
					<td>3º <br>Redes de Computadores</td>
					<td>3º <br>Segurança do Trabalho</td>
					<td>3º <br>Informática</td>
				</tr>
				
				<tr>
						<?php 
		                	 require_once("../controller/cProfessores.php");
		                	 $cMaterias = new cProfessores();
		                	 $sql = $cMaterias->MostrarMateriasProfessores();
		                     while ($dados = mysqli_fetch_assoc($sql)) {
		                     	$id = $dados['professor_id']."<br>".$dados['materia_id'];
		                        $nome = $dados['professor_nome']."<br>".$dados['materia_nome'];
		                        $materia[$id] = $nome;
		                     }

		                     $materias = shuffle($materia);	                    
		                     foreach ($materia as $materias){
		                         echo "<td>".$materias."</td>";
		                     }
		                    
		                ?>
					</tr>
					<tr>
						<?php
		                     while ($dados = mysqli_fetch_assoc($sql)) {
		                     	$id = $dados['professor_id']."<br>".$dados['materia_id'];
		                        $nome = $dados['professor_nome']."<br>".$dados['materia_nome'];
		                        $materia[$id] = $nome;
		                     }

		                     $materias = shuffle($materia);	                    
		                     foreach ($materia as $materias){
		                         echo "<td>".$materias."</td>";
		                     }
		                    
		                ?>
					</tr>
					<tr>
						<?php
		                     while ($dados = mysqli_fetch_assoc($sql)) {
		                     	$id = $dados['professor_id']."<br>".$dados['materia_id'];
		                        $nome = $dados['professor_nome']."<br>".$dados['materia_nome'];
		                        $materia[$id] = $nome;
		                     }

		                     $materias = shuffle($materia);	                    
		                     foreach ($materia as $materias){
		                         echo "<td>".$materias."</td>";
		                     }
		                    
		                ?>
					</tr>
					<tr>
						<?php
		                     while ($dados = mysqli_fetch_assoc($sql)) {
		                     	$id = $dados['professor_id']."<br>".$dados['materia_id'];
		                        $nome = $dados['professor_nome']."<br>".$dados['materia_nome'];
		                        $materia[$id] = $nome;
		                     }

		                     $materias = shuffle($materia);	                    
		                     foreach ($materia as $materias){
		                         echo "<td>".$materias."</td>";
		                     }
		                    
		                ?>
					</tr>
					<tr>
						<?php
		                     while ($dados = mysqli_fetch_assoc($sql)) {
		                     	$id = $dados['professor_id']."<br>".$dados['materia_id'];
		                        $nome = $dados['professor_nome']."<br>".$dados['materia_nome'];
		                        $materia[$id] = $nome;
		                     }

		                     $materias = shuffle($materia);	                    
		                     foreach ($materia as $materias){
		                         echo "<td>".$materias."</td>";
		                     }
		                    
		                ?>
					</tr>
					<tr>
						<?php
		                     while ($dados = mysqli_fetch_assoc($sql)) {
		                     	$id = $dados['professor_id']."<br>".$dados['materia_id'];
		                        $nome = $dados['professor_nome']."<br>".$dados['materia_nome'];
		                        $materia[$id] = $nome;
		                     }

		                     $materias = shuffle($materia);	                    
		                     foreach ($materia as $materias){
		                         echo "<td>".$materias."</td>";
		                     }
		                    
		                ?>
					</tr>
					<tr>
						<?php
		                     while ($dados = mysqli_fetch_assoc($sql)) {
		                     	$id = $dados['professor_id']."<br>".$dados['materia_id'];
		                        $nome = $dados['professor_nome']."<br>".$dados['materia_nome'];
		                        $materia[$id] = $nome;
		                     }

		                     $materias = shuffle($materia);	                    
		                     foreach ($materia as $materias){
		                         echo "<td>".$materias."</td>";
		                     }
		                    
		                ?>
					</tr>
					<tr>
						<?php
		                     while ($dados = mysqli_fetch_assoc($sql)) {
		                     	$id = $dados['professor_id']."<br>".$dados['materia_id'];
		                        $nome = $dados['professor_nome']."<br>".$dados['materia_nome'];
		                        $materia[$id] = $nome;
		                     }

		                     $materias = shuffle($materia);	                    
		                     foreach ($materia as $materias){
		                         echo "<td>".$materias."</td>";
		                     }
		                    
		                ?>
					</tr>
					<tr>
						<?php
		                     while ($dados = mysqli_fetch_assoc($sql)) {
		                     	$id = $dados['professor_id']."<br>".$dados['materia_id'];
		                        $nome = $dados['professor_nome']."<br>".$dados['materia_nome'];
		                        $materia[$id] = $nome;
		                     }

		                     $materias = shuffle($materia);	                    
		                     foreach ($materia as $materias){
		                         echo "<td>".$materias."</td>";
		                     }
		                    
		                ?>
					</tr>
			</table>
		</div>
	</div>