<?php 

    require_once("cProfessores.php");

    $c_prof = new  cProfessores();

    if (isset($_POST['cad_nome'],$_POST['cad_sobrenome'],$_POST['cad_email'],$_POST['cad_senha'],$_POST['cad_telefone'],$_POST['cad_cpf'],$_POST['cad_nasc'],$_POST['cad_nasc'],$_POST['cad_disciplina'],$_POST['cad_folgas'])) {
        $c_prof->Inserir($_POST['cad_nome'],$_POST['cad_sobrenome'],$_POST['cad_email'],$_POST['cad_senha'],$_POST['cad_telefone'],$_POST['cad_cpf'],$_POST['cad_nasc'],$_POST['cad_nasc'],$_POST['cad_disciplina'],$_POST['cad_folgas']);
    }

?>