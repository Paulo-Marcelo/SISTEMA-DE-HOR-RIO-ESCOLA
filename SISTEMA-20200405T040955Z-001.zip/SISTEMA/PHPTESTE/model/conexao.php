<?php
class conexao {
	private $servidor = "localhost";
	private $usuario = "root";
	private $senha = "";
	private $banco = "mydb";

	private $con;

	public function __construct() {
		$this->conectar();	
	}

	public function conectar() {
		$this->con = mysqli_connect($this->servidor, $this->usuario, $this->senha, $this->banco);
		$this->con->set_charset("utf8");
	}

	public function executar($query) {
		$sql = mysqli_query($this->con, $query);
		return $sql;
	}

	public function desconectar() {
		mysqli_close($this->con);
	}
}
?>
