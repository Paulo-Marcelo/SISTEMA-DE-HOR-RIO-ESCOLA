-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: 20-Fev-2020 às 13:11
-- Versão do servidor: 5.7.26
-- versão do PHP: 7.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mydb`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_materia`
--

DROP TABLE IF EXISTS `tb_materia`;
CREATE TABLE IF NOT EXISTS `tb_materia` (
  `materia_id` int(11) NOT NULL AUTO_INCREMENT,
  `materia_nome` varchar(45) NOT NULL,
  `materia_tipo` varchar(45) NOT NULL,
  PRIMARY KEY (`materia_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `tb_materia`
--

INSERT INTO `tb_materia` (`materia_id`, `materia_nome`, `materia_tipo`) VALUES
(1, 'Português', ''),
(2, 'Matemática', ''),
(3, 'Biologia', ''),
(4, 'Quimíca', ''),
(5, 'Física', ''),
(6, 'Inglês', ''),
(7, 'Espanhol', ''),
(8, 'Geografia', ''),
(9, 'História', ''),
(10, 'Artes', ''),
(11, 'Filosofia', ''),
(12, 'Sociologia', ''),
(13, 'Educação Física', ''),
(14, 'Projeto de Vida', '');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_materia_has_tb_professor`
--

DROP TABLE IF EXISTS `tb_materia_has_tb_professor`;
CREATE TABLE IF NOT EXISTS `tb_materia_has_tb_professor` (
  `tb_materia_meteria_id` int(11) NOT NULL,
  `tb_professor_professor_id` int(11) NOT NULL,
  PRIMARY KEY (`tb_materia_meteria_id`,`tb_professor_professor_id`),
  KEY `fk_tb_materia_has_tb_professor_tb_professor1_idx` (`tb_professor_professor_id`),
  KEY `fk_tb_materia_has_tb_professor_tb_materia1_idx` (`tb_materia_meteria_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `tb_materia_has_tb_professor`
--

INSERT INTO `tb_materia_has_tb_professor` (`tb_materia_meteria_id`, `tb_professor_professor_id`) VALUES
(1, 5),
(10, 19);

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_professor`
--

DROP TABLE IF EXISTS `tb_professor`;
CREATE TABLE IF NOT EXISTS `tb_professor` (
  `professor_id` int(11) NOT NULL AUTO_INCREMENT,
  `professor_nome` varchar(45) NOT NULL,
  `professor_atuacao` varchar(45) NOT NULL,
  `professor_folga` varchar(45) NOT NULL,
  `professor_sobrenome` varchar(100) NOT NULL,
  `professor_email` varchar(500) NOT NULL,
  `professor_senha` varchar(50) NOT NULL,
  `professor_telefone` varchar(500) NOT NULL,
  `professor_cpf` varchar(500) NOT NULL,
  `professor_nasc` varchar(500) NOT NULL,
  PRIMARY KEY (`professor_id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `tb_professor`
--

INSERT INTO `tb_professor` (`professor_id`, `professor_nome`, `professor_atuacao`, `professor_folga`, `professor_sobrenome`, `professor_email`, `professor_senha`, `professor_telefone`, `professor_cpf`, `professor_nasc`) VALUES
(5, 'Géssica', 'Português', 'Quinta', 'Eryonnara', '', '', '', '', ''),
(6, 'Luis', '', '', 'Ricardo', '', '', '', '', ''),
(7, 'Aerton', '', '', 'Wariss', '', '', '', '', ''),
(8, 'Carlos', '', '', 'Estevão', '', '', '', '', ''),
(9, 'Jardel', '', '', 'Pinho', '', '', '', '', ''),
(10, 'Laercio', '', '', 'Sousa', '', '', '', '', ''),
(11, 'Moisés', '', '', 'Furtado', '', '', '', '', ''),
(12, 'Herberth', '', '', 'Pincer', '', '', '', '', ''),
(13, 'Moisés', '', '', 'Furtado', '', '', '', '', ''),
(14, 'Herberth', '', '', 'Pincer', '', '', '', '', ''),
(15, 'Claudiane', '', '', 'Severino', '', '', '', '', ''),
(16, 'Luciane', '', '', 'Medeiros', '', '', '', '', ''),
(17, 'Patricia', '', '', 'Silva', '', '', '', '', ''),
(18, 'Rafaela', '', '', 'Mendes', '', '', '', '', ''),
(19, 'Zeneide', '', '', 'Maria', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_professor_has_tb_turma`
--

DROP TABLE IF EXISTS `tb_professor_has_tb_turma`;
CREATE TABLE IF NOT EXISTS `tb_professor_has_tb_turma` (
  `tb_professor_professor_id` int(11) NOT NULL,
  `tb_turma_turma_id` int(11) NOT NULL,
  PRIMARY KEY (`tb_professor_professor_id`,`tb_turma_turma_id`),
  KEY `fk_tb_professor_has_tb_turma_tb_turma1_idx` (`tb_turma_turma_id`),
  KEY `fk_tb_professor_has_tb_turma_tb_professor_idx` (`tb_professor_professor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_turma`
--

DROP TABLE IF EXISTS `tb_turma`;
CREATE TABLE IF NOT EXISTS `tb_turma` (
  `turma_id` int(11) NOT NULL AUTO_INCREMENT,
  `turma_serie` varchar(45) NOT NULL,
  `turma_curso` varchar(45) NOT NULL,
  PRIMARY KEY (`turma_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_turma_has_tb_materia`
--

DROP TABLE IF EXISTS `tb_turma_has_tb_materia`;
CREATE TABLE IF NOT EXISTS `tb_turma_has_tb_materia` (
  `tb_turma_turma_id` int(11) NOT NULL,
  `tb_materia_meteria_id` int(11) NOT NULL,
  PRIMARY KEY (`tb_turma_turma_id`,`tb_materia_meteria_id`),
  KEY `fk_tb_turma_has_tb_materia_tb_materia1_idx` (`tb_materia_meteria_id`),
  KEY `fk_tb_turma_has_tb_materia_tb_turma1_idx` (`tb_turma_turma_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Constraints for dumped tables
--

--
-- Limitadores para a tabela `tb_materia_has_tb_professor`
--
ALTER TABLE `tb_materia_has_tb_professor`
  ADD CONSTRAINT `fk_tb_materia_has_tb_professor_tb_materia1` FOREIGN KEY (`tb_materia_meteria_id`) REFERENCES `tb_materia` (`materia_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_tb_materia_has_tb_professor_tb_professor1` FOREIGN KEY (`tb_professor_professor_id`) REFERENCES `tb_professor` (`professor_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `tb_professor_has_tb_turma`
--
ALTER TABLE `tb_professor_has_tb_turma`
  ADD CONSTRAINT `fk_tb_professor_has_tb_turma_tb_professor` FOREIGN KEY (`tb_professor_professor_id`) REFERENCES `tb_professor` (`professor_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_tb_professor_has_tb_turma_tb_turma1` FOREIGN KEY (`tb_turma_turma_id`) REFERENCES `tb_turma` (`turma_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `tb_turma_has_tb_materia`
--
ALTER TABLE `tb_turma_has_tb_materia`
  ADD CONSTRAINT `fk_tb_turma_has_tb_materia_tb_materia1` FOREIGN KEY (`tb_materia_meteria_id`) REFERENCES `tb_materia` (`materia_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_tb_turma_has_tb_materia_tb_turma1` FOREIGN KEY (`tb_turma_turma_id`) REFERENCES `tb_turma` (`turma_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
